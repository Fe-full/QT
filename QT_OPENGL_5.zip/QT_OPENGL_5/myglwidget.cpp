#include "myglwidget.h"
#include <GL/glu.h>
#include <QApplication>


MyGLWidget::MyGLWidget(QWidget *parent): QOpenGLWidget(parent),
    mFullScreen(false), mRotateTriangle(0.0f), mRotateQuad(0.0f)
{
    showNormal();
    startTimer(100);
}

MyGLWidget::~MyGLWidget()
{
}

void MyGLWidget::resizeGL(int w, int h)
{
    if(h == 0){
        h = 1;
    }
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0f, (GLfloat)w/(GLfloat)h, 0.1f, 100.0f);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void MyGLWidget::initializeGL()
{
    glShadeModel(GL_SMOOTH);
    glClearColor(0.0f, 0.0f, 1.0f, 0.0f);
    glClearDepth(1.0f);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);

    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
}

void MyGLWidget::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    glTranslatef(-1.5f, 0.0f, -6.0f);

    glRotatef(mRotateTriangle, 0.0f, 1.0f, 0.0f);
    glBegin(GL_TRIANGLES);
       glColor3f(1.0f, 0.0f, 0.0f);
       glVertex3f(0.0f, 1.0f, 0.0f);
       glColor3f(0.0f, 1.0f, 0.0f);
       glVertex3f(-1.0f, -1.0f, 0.0f);
       glColor3f(0.0f, 0.0f, 1.0f);
       glVertex3f(1.0f, -1.0f, 0.0f);
    glEnd();

    glLoadIdentity();
    glTranslatef(1.5f, 0.0f, -6.0f);
    glRotatef(mRotateQuad, 1.0f, 0.0f, 0.0f);
    glColor3f(0.5f, 0.5f, 1.0f);
    glBegin(GL_QUADS);
    glVertex3f(-1.0f, 1.0f, 0.0f);
    glVertex3f( 1.0f, 1.0f, 0.0f);
    glVertex3f( 1.0f,-1.0f, 0.0f);
    glVertex3f(-1.0f, -1.0f, 0.0f);
    glEnd();
}

void MyGLWidget::timerEvent(QTimerEvent *event)
{
    mRotateTriangle += 0.2f;
    mRotateQuad     -=0.15f;
    update();
    QOpenGLWidget::timerEvent(event);
}

void MyGLWidget::KeyPressEvent(QKeyEvent *event)
{
    switch(event->key()){
    case Qt::Key_F2:{
        mFullScreen = !mFullScreen;
        if(mFullScreen){
            showFullScreen();
        }
        else{
            showNormal();
        }
        update();
        break;
    }
    case Qt::Key_Escape:{
        qApp->exit();
        break;
    }
    }
}
















