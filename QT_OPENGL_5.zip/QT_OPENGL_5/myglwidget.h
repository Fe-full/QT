#ifndef MYGLWIDGET_H
#define MYGLWIDGET_H

#include <QOpenGLWidget>
#include <QKeyEvent>

class MyGLWidget : public QOpenGLWidget
{
    Q_OBJECT

public:
    MyGLWidget(QWidget *parent = nullptr);
    ~MyGLWidget();
protected:
    virtual void paintGL();
    virtual void initializeGL();
    virtual void resizeGL(int w, int h);
    virtual void timerEvent(QTimerEvent *event);
    virtual void KeyPressEvent(QKeyEvent *event);
private:
    bool mFullScreen;
    GLfloat mRotateTriangle;
    GLfloat mRotateQuad;

};
#endif // MYGLWIDGET_H
