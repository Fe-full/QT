#include "myglwidget.h"
#include <QOpenGLWidget>
#include <QApplication>
#include <GL/glu.h>
#include <QDebug>
#include <QOpenGLExtraFunctions>

//混合:
//OpenGL中的绝大多数特效都与某些类型的(色彩)混合有关。混色的定义为，将某个象素的颜色和已绘制在屏幕上与其对应的象素颜色相互结合。
//至于如何结合这两个颜色则依赖于颜色的alpha通道的分量值，以及/或者所使用的混色函数。Alpha通常是位于颜色值末尾的第4个颜色组成分量。
//前面这些课我们都是用GL_RGB来指定颜色的三个分量。相应的GL_RGBA可以指定alpha分量的值。
//更进一步，我们可以使用glColor4f()来代替glColor3f()。
//绝大多数人都认为Alpha分量代表材料的透明度。这就是说，alpha值为0.0时所代表的材料是完全透明的。
//alpha值为1.0时所代表的材料则是完全不透明的。
MyGLWidget::MyGLWidget(QWidget *parent) : QOpenGLWidget(parent), mLight(false), mFullScreen(false),
    mXRotate(0.0f), mYRotate(0.0f), mXSpeed(0.0f), mYSpeed(0.0f), mZ(-5.0f), mLightAmbient(),
    mLightDiffuse(), mLightPosition(), mFilter(0), mBlend(false)
{
    showNormal();
    startTimer(50);
}

MyGLWidget::~MyGLWidget()
{
    glDeleteTextures(3, &mTexture[0]);
}

void MyGLWidget::resizeGL(int w, int h)
{
    if(h == 0){
        h = 1;
    }
    glViewport(0, 0, w, h);       //重置当前的视口
    glMatrixMode(GL_PROJECTION);  // 选择投影矩阵
    glLoadIdentity();             // 重置投影矩阵
    //设置视口的大小
    gluPerspective(45.0f, (GLfloat)w/(GLfloat)h, 0.1f, 100.0f);

    glMatrixMode(GL_MODELVIEW);  //选择模型观察矩阵
    glLoadIdentity();            // 重置模型观察矩阵
}

//接着应该载入纹理并初始化OpenGL设置了。InitGL函数的第一行使用上面的代码载入纹理。创建纹理之后，我们调用
//glEnable(GL_TEXTURE_2D)启用2D纹理映射。阴影模式设为平滑阴影( smooth shading ）。
void MyGLWidget::initializeGL()
{
    loadGLTexture();
    glEnable(GL_TEXTURE_2D);  // 启用纹理映射
    glShadeModel(GL_SMOOTH);  // 启用阴影平滑

    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);  // 黑色背景
    glClearDepth(1.0f);       // 设置深度缓存
    glEnable(GL_DEPTH_TEST);  // 启用深度测试
    glDepthFunc(GL_LEQUAL);   // 所作深度测试的类型

    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST); // 告诉系统对透视进行修正

    //下面行设置环境光的发光量，光源light1开始发光。
    //开始处我们将环境光的发光量存放在LightAmbient数组中。
    //现在我们就使用此数组(半亮度环境光)。在int InitGL(GLvoid)函数中添加下面的代码。
    glLightfv(GL_LIGHT1, GL_AMBIENT, mLightAmbient);    // 设置环境光
    //接下来我们设置漫射光的发光量。它存放在LightDiffuse数组中(全亮度白光)
    glLightfv(GL_LIGHT1, GL_AMBIENT, mLightDiffuse);    // 设置漫射光
    //然后设置光源的位置。位置存放在 LightPosition 数组中(正好位于木箱前面的中心，
    //X－0.0f，Y－0.0f，Z方向移向观察者2个单位<位于屏幕外面>)。
    glLightfv(GL_LIGHT1, GL_POSITION, mLightPosition);  // 设置光源位置
    //我们启用一号光源。我们还没有启用GL_LIGHTING，所以您看不见任何光线。
    //记住：只对光源进行设置、定位、甚至启用，光源都不会工作。除非我们启用GL_LIGHTING
    glEnable(GL_LIGHT1);
    if(!mLight){
        glDisable(GL_LIGHTING);  // 禁用光源
    }
    else{
        glEnable(GL_LIGHTING);   // 启用光源
    }
    //加入以下两行。第一行以全亮度绘制此物体，并对其进行50%的alpha混合(半透明)。
    //当混合选项打开时，此物体将会产生50%的透明效果。第二行设置所采用的混合类型。
    //Rui Martins 的补充: alpha通道的值为 0.0意味着物体材质是完全透明的。1.0 则意味着完全不透明。
    glColor4f(1.0f, 1.0f, 1.0f, 0.5f);   // 全亮度， 50% Alpha 混合
    glBlendFunc(GL_SRC_ALPHA, GL_ONE);   // 基于源象素alpha通道值的半透明混合函数
    if(mBlend){                          // 打开混合
        glEnable(GL_BLEND);              // 关闭深度测试
    }
    else{
        glDisable(GL_BLEND);             // 关闭混合
        glEnable(GL_DEPTH_TEST);         // 打开深度测试
    }
}

//现在我们绘制贴图
//开始两行代码 glClear() 和 glLoadIdentity() 是第一课中就有的代码。
//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT) 清除屏幕并设为我们在 InitGL() 中选定的颜色
//深度缓存也被清除。模型观察矩阵也使用glLoadIdentity()重置。
void MyGLWidget::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);  // 清除屏幕和深度缓存
    glLoadIdentity();                                    // 重置当前的模型观察矩阵
    glTranslatef(0.0f, 0.0f, mZ);
    //下三行代码放置并旋转贴图立方体。glTranslatef(0.0f,0.0f,z)将立方体沿着Z轴移动Z单位。
    glRotatef(mXRotate, 1.0f, 0.0f, 0.0f);              // X轴旋转
    glRotatef(mYRotate, 0.0f, 1.0f, 0.0f);              // Y轴旋转

    //绑定的纹理texture[filter]
    //任何时候，我们按下F键，filter 的值就会增加。如果这个数值大于2，变量filter 将被重置为0。
    //程序初始时，变量filter 的值也将设为0。使用变量filter 我们就可以选择三种纹理中的任意一种。
    glBindTexture(GL_TEXTURE_2D, mTexture[mFilter]);  // 选择由filter决定的纹理

    //为了将纹理正确的映射到四边形上，您必须将纹理的右上角映射到四边形的右上角，纹理的左上角映射到四边形的左上角，
    //纹理的右下角映射到四边形的右下角，纹理的左下角映射到四边形的左下角。
    //如果映射错误的话，图像显示时可能上下颠倒，侧向一边或者什么都不是。
    //glTexCoord2f 的第一个参数是X坐标。 0.0f 是纹理的左侧。 0.5f 是纹理的中点， 1.0f 是纹理的右侧。
    //glTexCoord2f 的第二个参数是Y坐标。 0.0f 是纹理的底部。 0.5f 是纹理的中点， 1.0f 是纹理的顶部。
    //所以纹理的左上坐标是 X：0.0f，Y：1.0f ，四边形的左上顶点是 X： -1.0f，Y：1.0f 。其余三点依此类推。
    glBegin(GL_QUADS);
            // 前面
            glNormal3f( 0.0f, 0.0f, 1.0f);					// 法线指向观察者
            glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);	// 纹理和四边形的左下
            glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);	// 纹理和四边形的右下
            glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);	// 纹理和四边形的右上
            glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);	// 纹理和四边形的左上
            // 后面
            glNormal3f( 0.0f, 0.0f,-1.0f);					// 法线背向观察者
            glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);	// 纹理和四边形的右下
            glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);	// 纹理和四边形的右上
            glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);	// 纹理和四边形的左上
            glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);	// 纹理和四边形的左下
            // 顶面
            glNormal3f( 0.0f, 1.0f, 0.0f);					// 法线向上
            glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);	// 纹理和四边形的左上
            glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f,  1.0f,  1.0f);	// 纹理和四边形的左下
            glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f,  1.0f,  1.0f);	// 纹理和四边形的右下
            glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);	// 纹理和四边形的右上
            // 底面
            glNormal3f( 0.0f,-1.0f, 0.0f);					// 法线朝下
            glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, -1.0f, -1.0f);	// 纹理和四边形的右上
            glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f, -1.0f, -1.0f);	// 纹理和四边形的左上
            glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);	// 纹理和四边形的左下
            glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);	// 纹理和四边形的右下

            // 右面
            glNormal3f( 1.0f, 0.0f, 0.0f);					// 法线朝右
            glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);	// 纹理和四边形的右下
            glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);	// 纹理和四边形的右上
            glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);	// 纹理和四边形的左上
            glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);	// 纹理和四边形的左下

            // 左面
            glNormal3f(-1.0f, 0.0f, 0.0f);					// 法线朝左
            glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);	// 纹理和四边形的左下
            glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);	// 纹理和四边形的右下
            glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);	// 纹理和四边形的右上
            glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);	// 纹理和四边形的左上
        glEnd();
}

void MyGLWidget::keyPressEvent(QKeyEvent *event)
{
    switch(event->key())
    {
    case Qt::Key_F2:
    {
        mFullScreen = !mFullScreen;
        if (mFullScreen) {
            showFullScreen();
        }
        else {
            showNormal();
        }
        update();
        break;
    }
    case Qt::Key_L:
    {
        mLight = !mLight;
        if (!mLight) {
            glDisable(GL_LIGHTING);		// 禁用光源
        }
        else {
            glEnable(GL_LIGHTING);		// 启用光源
        }
        break;
    }
    case Qt::Key_F:
    {
        mFilter+=1;
        if (mFilter > 2) {
            mFilter = 0;
        }
        qDebug() << "mFilter = " << mFilter;
        break;
    }
    case Qt::Key_PageUp:
    {
        mZ-=0.2f;
        break;
    }
    case Qt::Key_PageDown:
    {
        mZ+=0.2f;
        break;
    }
    case Qt::Key_Up:
    {
        mXSpeed-=0.01f;
        break;
    }
    case Qt::Key_Down:
    {
        mYSpeed+=0.01f;
        break;
    }
    case Qt::Key_Right:
    {
        mYSpeed+=0.01f;
        break;
    }
    case Qt::Key_Left:
    {
        mYSpeed-=0.01f;
        break;
    }
    case Qt::Key_Escape:
    {
        qApp->exit();
        break;
    }
    case Qt::Key_B:
    {
        mBlend = !mBlend;				// 切换混合选项的 TRUE / FALSE
        if (mBlend) {
            glEnable(GL_BLEND);		// 打开混合
            glDisable(GL_DEPTH_TEST);	// 关闭深度测试

        }
        else {
            glDisable(GL_BLEND);		// 关闭混合
            glEnable(GL_DEPTH_TEST);	// 打开深度测试
        }
        break;
    }
    }
}

void MyGLWidget::timerEvent(QTimerEvent *timerevent)
{
    //现在增加 xrot , yrot 和 zrot 的值。
    //尝试变化每次各变量的改变值来调节立方体的旋转速度，或改变+/-号来调节立方体的旋转方向。
    mXRotate += mXSpeed;
    mYRotate += mYSpeed;
    update();
    QOpenGLWidget::timerEvent(timerevent);
}

void MyGLWidget::loadGLTexture()
{
    QImage image(":/images/Glass.bmp");
    image = image.convertToFormat(QImage::Format_RGB888);
    image = image.mirrored();

    glGenTextures(3, &mTexture[0]);   // 创建纹理
    //接着我们要创建的第一种纹理使用 GL_NEAREST方式。从原理上讲，这种方式没有真正进行滤波。
    //它只占用很小的处理能力，看起来也很差。唯一的好处是这样我们的工程在很快和很慢的机器上都可以正常运行。
    //您会注意到我们在 MIN 和 MAG 时都采用了GL_NEAREST,你可以混合使用 GL_NEAREST 和 GL_LINEAR。
    //纹理看起来效果会好些，但我们更关心速度，所以全采用低质量贴图。MIN_FILTER在图像绘制时小于贴图的原始尺寸时采用。
    //MAG_FILTER在图像绘制时大于贴图的原始尺寸时采用。
    // 创建 Nearest 滤波贴图
    glBindTexture(GL_TEXTURE_2D, mTexture[0]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, 3, image.width(),
                 image.height(), 0, GL_RGB, GL_UNSIGNED_BYTE, image.bits());

    //当图像在屏幕上变得很小的时候，很多细节将会丢失。刚才还很不错的图案变得很难看。
    //当您告诉OpenGL创建一个 mipmapped的纹理后，OpenGL将尝试创建不同尺寸的高质量纹理。当您向屏幕绘制一个 mipmapped纹理的时候，
    //OpenGL将选择它已经创建的外观最佳的纹理(带有更多细节)来绘制，而不仅仅是缩放原先的图像(这将导致细节丢失)。
    //有办法可以绕过OpenGL对纹理宽度和高度所加的限制——64、128、256，等等。
    //办法就是 gluBuild2DMipmaps。据我的发现，您可以使用任意的位图来创建纹理。OpenGL将自动将它缩放到正常的大小。
    //因为是第三个纹理，我们将它存到texture[2]。这样三个纹理全都创建好了。
    // 创建 MipMapped 纹理
    glBindTexture(GL_TEXTURE_2D, mTexture[2]);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
    gluBuild2DMipmaps(GL_TEXTURE_2D, 3, image.width(),
                      image.width(), GL_RGB, GL_UNSIGNED_BYTE, image.bits());

}


















