﻿#include "myglwidget.h"
#include <GL/glu.h>
#include <QApplication>


MyGLWidget::MyGLWidget(QWidget *parent)
    : QOpenGLWidget(parent), mFullScreen(false), mRotateTriangle(0.0f), mRotateQuad(0.0f)
{
    showNormal();
    startTimer(50);
}

MyGLWidget::~MyGLWidget()
{
}

void MyGLWidget::resizeGL(int w, int h)
{
    if(h == 0){
        h = 1;
    }
    glViewport(0, 0, w, h);
    //下面几行为透视图设置屏幕。意味着越远的东西看起来越小。这么做创建了一个现实外观的场景。
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0f, (GLfloat)w/(GLfloat)h, 0.1f, 100.0f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void MyGLWidget::initializeGL()
{
    glShadeModel(GL_SMOOTH);
    glClearColor(0.0f, 0.0f, 1.0f, 0.0f);
    glClearDepth(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
}

void MyGLWidget::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    glTranslatef(-1.5f, 0.0f, -6.0f);

    glRotatef(mRotateTriangle, 0.0f, 1.0f, 0.0f);
    glBegin(GL_TRIANGLES);
    //上顶点在底面的投影位于底面的中心
    glColor3f( 1.0f, 0.0f, 0.0f);
    glVertex3f(0.0f, 1.0f, 0.0f);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);
    //现在绘制右侧面。注意其底边上的两个顶点的X坐标位于中心右侧的一个单位处
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex3f(0.0f, 1.0f, 0.0f);
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);
    //现在是后侧面。再次切换颜色。左下顶点又回到绿色，因为后侧面与右侧面共享这个角。
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex3f(0.0f, 1.0f, 0.0f);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex3f(-1.0f, -1.0f, -1.0f);
    //最后画左侧面。又要切换颜色。左下顶点是蓝色，与后侧面的右下顶点相同。
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex3f(0.0f, 1.0f, 0.0f);
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex3f(-1.0f, -1.0f, -1.0f);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);
    glEnd();

    glLoadIdentity();
    glTranslatef(1.5f,0.0f,-7.0f);				// 先右移再移入屏幕
    glRotatef(mRotateQuad,1.0f,1.0f,1.0f);			// XYZ轴上旋转立方体
    glBegin(GL_QUADS);
    //然后是靠近观察者的左下和右下顶点。就是屏幕往外一单位。
    glColor3f(0.0f,1.0f,0.0f);			// 颜色改为蓝色
    glVertex3f( 1.0f, 1.0f,-1.0f);			// 四边形的右上顶点 (顶面)
    glVertex3f(-1.0f, 1.0f,-1.0f);			// 四边形的左上顶点 (顶面)
    glVertex3f(-1.0f, 1.0f, 1.0f);			// 四边形的左下顶点 (顶面)
    glVertex3f( 1.0f, 1.0f, 1.0f);
    //但一旦您进入象纹理映射这样的领域时，忽略绘制次序会导致十分怪异的结果。
    glColor3f(1.0f,0.5f,0.0f);			// 颜色改成橙色
    glVertex3f( 1.0f,-1.0f, 1.0f);			// 四边形的右上顶点(底面)
    glVertex3f(-1.0f,-1.0f, 1.0f);			// 四边形的左上顶点(底面)
    glVertex3f(-1.0f,-1.0f,-1.0f);			// 四边形的左下顶点(底面)
    glVertex3f( 1.0f,-1.0f,-1.0f);
    //接着画立方体的前面。保持Z坐标为一单位，前面正对着我们
    glColor3f(1.0f,0.0f,0.0f);			// 颜色改成红色
    glVertex3f( 1.0f, 1.0f, 1.0f);			// 四边形的右上顶点(前面)
    glVertex3f(-1.0f, 1.0f, 1.0f);			// 四边形的左上顶点(前面)
    glVertex3f(-1.0f,-1.0f, 1.0f);			// 四边形的左下顶点(前面)
    glVertex3f( 1.0f,-1.0f, 1.0f);
    //立方体后面的绘制方法与前面类似。只是位于屏幕的里面。
    glColor3f(1.0f,1.0f,0.0f);			// 颜色改成黄色
    glVertex3f( 1.0f,-1.0f,-1.0f);			// 四边形的右上顶点(后面)
    glVertex3f(-1.0f,-1.0f,-1.0f);			// 四边形的左上顶点(后面)
    glVertex3f(-1.0f, 1.0f,-1.0f);			// 四边形的左下顶点(后面)
    glVertex3f( 1.0f, 1.0f,-1.0f);
    //还剩两个面就完成了。您会注意到总有一个坐标保持不变。这一次换成了X坐标。
    glColor3f(0.0f,0.0f,1.0f);			// 颜色改成蓝色
    glVertex3f(-1.0f, 1.0f, 1.0f);			// 四边形的右上顶点(左面)
    glVertex3f(-1.0f, 1.0f,-1.0f);			// 四边形的左上顶点(左面)
    glVertex3f(-1.0f,-1.0f,-1.0f);			// 四边形的左下顶点(左面)
    glVertex3f(-1.0f,-1.0f, 1.0f);
    //您会看见一个非常漂亮的彩色立方体，各种颜色在它的各个表面流淌。
    glColor3f(1.0f,0.0f,1.0f);			// 颜色改成紫罗兰色
    glVertex3f( 1.0f, 1.0f,-1.0f);			// 四边形的右上顶点(右面)
    glVertex3f( 1.0f, 1.0f, 1.0f);			// 四边形的左上顶点(右面)
    glVertex3f( 1.0f,-1.0f, 1.0f);			// 四边形的左下顶点(右面)
    glVertex3f( 1.0f,-1.0f,-1.0f);			// 四边形的右下顶点(右面)
    glEnd();
}

void MyGLWidget::timerEvent(QTimerEvent *event)
{
    //并试着将0.2改成1.0。这个数字越大，物体就转的越快，这个数字越小，物体转的就越慢。
    mRotateTriangle += 5.0f;						// 增加三角形的旋转变量
    mRotateQuad -= 0.3f;
    update();
    QOpenGLWidget::timerEvent(event);
}

void MyGLWidget::keyPressEvent(QKeyEvent *event)
{
    switch(event->key()){
    case Qt::Key_F2:{
        mFullScreen = !mFullScreen;
        if(mFullScreen){
            showFullScreen();
        }
        else{
            showNormal();
        }
        update();
        break;
    }
    case Qt::Key_Escape:{
        qApp->exit();
        break;
    }
    }
}






















