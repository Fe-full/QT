#ifndef MYGLWIDGET_H
#define MYGLWIDGET_H

#include <QWidget>
#include <QGLWidget>
#include <QKeyEvent>


class MyGLWidget : public QGLWidget
{
    Q_OBJECT

public:
    MyGLWidget(QWidget *parent = nullptr);
    ~MyGLWidget();
protected:
    virtual void paintGL();
    virtual void initializeGL();
    virtual void resizeGL(int w, int h);
    virtual void timerEvent(QTimerEvent *event);
    virtual void keyPressEvent(QKeyEvent *event);

private:
    void loadGLTexture();
private:
    bool mLight;
    bool mFullScreen;

    GLfloat mXRotate;
    GLfloat mYRotate;
    GLfloat mXSpeed;
    GLfloat mYSpeed;
    GLfloat mZ;

    GLfloat mLightAmbient[4]={0.5f, 0.5f, 0.5f, 1.0f};
    GLfloat mLightDiffuse[4]={1.0f, 1.0f, 1.0f, 1.0f};
    GLfloat mLightPosition[4]={0.0f, 0.0f, 2.0f, 1.0f};

    GLuint mFilter;
    GLuint mTexture[3];

};
#endif // MYGLWIDGET_H









